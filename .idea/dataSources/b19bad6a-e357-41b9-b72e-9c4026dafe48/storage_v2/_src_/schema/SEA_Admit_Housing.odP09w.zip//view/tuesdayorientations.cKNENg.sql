create view tuesdayorientations as
select `sea admit housing`.`orientations`.`Email` AS `Email`
from `sea admit housing`.`orientations`
where (`sea admit housing`.`orientations`.`Orientation` like 'Tuesday%');

