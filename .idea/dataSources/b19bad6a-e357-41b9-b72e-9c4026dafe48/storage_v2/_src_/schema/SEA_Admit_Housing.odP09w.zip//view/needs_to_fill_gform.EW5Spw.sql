create definer = root@localhost view needs_to_fill_gform as
select `sea admit housing`.`hosts`.`UID_number` AS `UID_number`, `sea admit housing`.`hosts`.`Email` AS `Email`
from (`sea admit housing`.`hosts`
         left join `sea admit housing`.`orientations`
                   on ((`sea admit housing`.`hosts`.`UID_number` = `sea admit housing`.`orientations`.`UID_number`)))
where isnull(`sea admit housing`.`orientations`.`Orientation`);

