create definer = root@localhost view num_hostees_in_each_room as
select distinct `sea admit housing`.`hosts`.`Residential_Building` AS `Residential_Building`,
                `sea admit housing`.`hosts`.`Room_Number`          AS `Room_Number`,
                `sea admit housing`.`hosts`.`Your_Gender`          AS `Your_Gender`,
                `sea admit housing`.`hostees_per_room`.`Hostees`   AS `Hostees`
from (`sea admit housing`.`hosts`
         join `sea admit housing`.`hostees_per_room` on (((`sea admit housing`.`hosts`.`Residential_Building` =
                                                           `sea admit housing`.`hostees_per_room`.`Residential_Building`) and
                                                          (`sea admit housing`.`hosts`.`Room_Number` =
                                                           `sea admit housing`.`hostees_per_room`.`Room_Number`))));

