create definer = root@localhost view hedrick_court_rooms as
select `sea admit housing`.`hosts`.`UID_number`           AS `UID_number`,
       `sea admit housing`.`hosts`.`Residential_Building` AS `Residential_Building`,
       `sea admit housing`.`hosts`.`Room_Number`          AS `Room_Number`
from `sea admit housing`.`hosts`
where ((`sea admit housing`.`hosts`.`Residential_Building` like 'Hedrick%') or
       (`sea admit housing`.`hosts`.`Residential_Building` = 'Hitch'))
order by `sea admit housing`.`hosts`.`Residential_Building`;

