create definer = root@localhost view sunset_village_rooms as
select `sea admit housing`.`hosts`.`UID_number`           AS `UID_number`,
       `sea admit housing`.`hosts`.`Residential_Building` AS `Residential_Building`,
       `sea admit housing`.`hosts`.`Room_Number`          AS `Room_Number`
from `sea admit housing`.`hosts`
where ((`sea admit housing`.`hosts`.`Residential_Building` like 'Delta%') or
       (`sea admit housing`.`hosts`.`Residential_Building` like 'Canyon%') or
       (`sea admit housing`.`hosts`.`Residential_Building` like 'Court%'))
order by `sea admit housing`.`hosts`.`Residential_Building`;

